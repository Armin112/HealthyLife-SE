<?php
class Disease_model extends CI_model{
}