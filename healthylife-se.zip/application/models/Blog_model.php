<?php
class Blog_model extends CI_model{
}